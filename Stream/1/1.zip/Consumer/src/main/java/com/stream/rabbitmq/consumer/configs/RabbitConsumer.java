package com.stream.rabbitmq.consumer.configs;

import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Flux;

import java.time.Duration;
import java.util.function.Consumer;

@Slf4j
@Component
public class RabbitConsumer {

    @Bean
    public Consumer<Flux<String>> wikimedia() {
        return flux -> flux
                .bufferTimeout(5, Duration.ofSeconds(5))
                .subscribe(batch -> {
                    log.info("Received batch of {} messages", batch.size());
                    for (String msg : batch) {
                        log.info(" - {}", msg);
                    }
                });
    }

    @Bean
    public Consumer<String> rajat() {
        return (message) -> {
            log.info("Received the value {} in Rajat", message);
        };
    }
}
