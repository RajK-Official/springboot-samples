//package com.stream.rabbitmq.producer.configs;
//
//import org.springframework.amqp.rabbit.connection.CachingConnectionFactory;
//import org.springframework.amqp.rabbit.connection.ConnectionFactory;
//import org.springframework.amqp.rabbit.core.RabbitTemplate;
//import org.springframework.boot.autoconfigure.amqp.RabbitProperties;
//import org.springframework.boot.context.properties.ConfigurationProperties;
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//
//@Configuration
//public class RabbitConfig {
//
//    @Bean
//    @ConfigurationProperties("spring.rabbitmq.properties")
//    public RabbitProperties properties() {
//        return new RabbitProperties();
//    }
//
//    @Bean
//    public ConnectionFactory connectionFactory() {
//        RabbitProperties rabbitProperties = properties();
//        CachingConnectionFactory connectionFactory = new CachingConnectionFactory();
//        connectionFactory.setHost(rabbitProperties.getHost());
//        connectionFactory.setPort(rabbitProperties.getPort());
//        connectionFactory.setUsername(rabbitProperties.getUsername());
//        connectionFactory.setPassword(rabbitProperties.getPassword());
//        if (rabbitProperties.getVirtualHost() != null) {
//            connectionFactory.setVirtualHost(rabbitProperties.getVirtualHost());
//        }
//        return connectionFactory;
//    }
//
//    @Bean
//    public RabbitTemplate rabbitTemplate(ConnectionFactory connectionFactory) {
//        return new RabbitTemplate(connectionFactory);
//    }
//
//}
