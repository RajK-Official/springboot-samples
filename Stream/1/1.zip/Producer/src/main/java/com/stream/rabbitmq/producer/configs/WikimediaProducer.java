package com.stream.rabbitmq.producer.configs;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.stream.function.StreamBridge;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import java.time.Duration;

@Service
public class WikimediaProducer {
    private final StreamBridge streamBridge;
    private final ObjectMapper objectMapper;

    @Value("${wikimedia.stream-url}")
    private String streamUrl;

    public WikimediaProducer(ObjectMapper objectMapper, StreamBridge streamBridge) {
        this.objectMapper = objectMapper;
        this.streamBridge = streamBridge;
    }

    @PostConstruct
    public void startStreaming() throws InterruptedException {
        WebClient.create()
                .get()
                .uri(streamUrl)
                .accept(MediaType.TEXT_EVENT_STREAM)
                .retrieve()
                .bodyToFlux(String.class)
                .delayElements(Duration.ofSeconds(5))
                .subscribe(this::sendToRabbitMQ);
    }

    private void sendToRabbitMQ(String jsonEvent) {
        try {
            JsonNode node = objectMapper.readTree(jsonEvent);
            streamBridge.send("wikimedia-out-0", jsonEvent);
            System.out.println("Sent event to RabbitMQ: " + node.path("meta").path("uri"));
        } catch (JsonProcessingException e) {
            System.err.println("Invalid JSON received: " + e.getMessage());
        }
    }

}
